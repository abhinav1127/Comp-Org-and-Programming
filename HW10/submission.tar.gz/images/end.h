/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 end 5.png 
 * Time-stamp: Thursday 11/15/2018, 22:16:53
 * 
 * Image Information
 * -----------------
 * 5.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef END_H
#define END_H

extern const unsigned short end[38400];
#define _SIZE 76800
#define _LENGTH 38400
#define _WIDTH 240
#define _HEIGHT 160

#endif

