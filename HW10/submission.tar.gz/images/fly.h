/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 fly fly.png 
 * Time-stamp: Thursday 11/15/2018, 21:23:18
 * 
 * Image Information
 * -----------------
 * fly.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLY_H
#define FLY_H

extern const unsigned short fly[400];
#define FLY_SIZE 800
#define FLY_LENGTH 400
#define FLY_WIDTH 20
#define FLY_HEIGHT 20

#endif

