/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=20x20 halfback halfback.png 
 * Time-stamp: Thursday 11/15/2018, 09:06:33
 * 
 * Image Information
 * -----------------
 * halfback.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HALFBACK_H
#define HALFBACK_H

extern const unsigned short halfback[400];
#define HALFBACK_SIZE 800
#define HALFBACK_LENGTH 400
#define HALFBACK_WIDTH 20
#define HALFBACK_HEIGHT 20

#endif

